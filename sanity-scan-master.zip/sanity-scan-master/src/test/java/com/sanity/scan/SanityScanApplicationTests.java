package com.sanity.scan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SanityScanApplicationTests {

	@Test
	void contextLoads() {
	}

}
